# Handles the "operator" agent mode by interacting with a local service to list tasks and cases.
# Wrap existing commands like "list tasks" and "list cases", claim, done, etc.


# TODO: MOVE THE LOGIC FROM orchestrator.py INTO THIS AGENT CLASS !!!!!!!!!!!!!!!!!!!!!!!!!!!!

from __future__ import annotations
import os
import httpx
from .base import Agent, AgentState
from .settings import LLM_USE
from .llm_utils import parse_operator_command_with_llm

LOCAL_URL = os.getenv("LOCAL_URL", "http://127.0.0.1:8000/local")


class OperatorAgent(Agent):
    name = "operator"

    async def handle(self, state: AgentState) -> AgentState:
        text = state.get("message", "").lower()

        cmd = None
        if LLM_USE:
            try:
                cmd = await parse_operator_command_with_llm(state.get("message", ""))
            except Exception:
                cmd = None


        # Simple command parsing (rule-based). You can later swap this with an LLM tool caller.
        # Examples:
        #   - list tasks
        #   - list cases
        #   - claim task 12
        #   - complete task 12
        #   - advance case CASE-1 to READY_FOR_PICKUP
        async with httpx.AsyncClient() as client:
            if cmd:
                action = (cmd.get("action") or "unknown").lower()

                if action == "list_tasks":
                    tasks = (await client.get(f"{LOCAL_URL}/tasks")).json()
                    state.setdefault("steps", []).append({"tasks": tasks})
                    state["reply"] = f"Found {len(tasks)} tasks."
                    return state

                if action == "list_cases":
                    cases = (await client.get(f"{LOCAL_URL}/cases")).json()
                    state.setdefault("steps", []).append({"cases": cases})
                    state["reply"] = f"Found {len(cases)} cases."
                    return state

                if action == "claim_task" and cmd.get("task_id") is not None:
                    task_id = int(cmd["task_id"])
                    r = await client.post(f"{LOCAL_URL}/tasks/{task_id}/claim")
                    r.raise_for_status()
                    state.setdefault("steps", []).append({"claim": r.json()})
                    state["reply"] = f"Task {task_id} claimed."
                    return state

                if action == "complete_task" and cmd.get("task_id") is not None:
                    task_id = int(cmd["task_id"])
                    r = await client.post(f"{LOCAL_URL}/tasks/{task_id}/complete")
                    r.raise_for_status()
                    state.setdefault("steps", []).append({"complete": r.json()})
                    state["reply"] = f"Task {task_id} completed."
                    return state

                if action == "advance_case" and cmd.get("case_id") and cmd.get("status"):
                    case_id = str(cmd["case_id"])
                    next_status = str(cmd["status"])
                    r = await client.patch(f"{LOCAL_URL}/cases/{case_id}", params={"status": next_status})
                    r.raise_for_status()
                    state.setdefault("steps", []).append({"advance": r.json()})
                    state["reply"] = f"Case {case_id} updated to {next_status}."
                    return state

        state["reply"] = "Operator mode: try 'list tasks' or 'list cases'."
        state["next_agent"] = None
        return state
