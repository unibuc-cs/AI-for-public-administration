# This pulls OCR-recognized docs from  /local/uploads.
# LLM usage: e.g., normalize document names
# User says: “am pus poza cu certificatul copilului”. OCR says: certificat copil. You want canonical cert_nastere.

# TODO: DocIntake Agent, for each OCR label, you run this and store the canonical one.

from __future__ import annotations
import os
import httpx
from .base import Agent, AgentState
from .llm_utils import client

LOCAL_URL = os.getenv("LOCAL_URL", "http://127.0.0.1:8000/local")

# Keep LLM calls off by default (safe for local demos without API keys).
# If you want LLM-based normalization, set:
#   DOC_NORMALIZE_WITH_LLM=1  and  OPENAI_API_KEY=...
USE_LLM_NORMALIZE = os.getenv("DOC_NORMALIZE_WITH_LLM", "0") == "1"

# Canonical document keys used across CI + Social flows (extend as you add new checklists).
CANONICAL_KEYS = {
    # CI
    "cert_nastere",
    "ci_veche",
    "dovada_adresa",
    "politie",
    # Social
    "cerere_ajutor",
    "carte_identitate",
    "acte_venit",
    "acte_locuire",
    "acte_familie",
    "cont_bancar",
}


NORMALIZE_PROMPT = """Map the following Romanian document description to one of the canonical keys:
CI-related:
- cert_nastere
- ci_veche
- politie
- dovada_adresa
Social-related:
- cerere_ajutor
- carte_identitate
- acte_venit
- acte_locuire
- acte_familie
- cont_bancar

If you can't decide, return "unknown".
Return ONLY JSON: {"canonical": "..."}.
"""


def _normalize_rule_based(label: str) -> str:
    """Cheap deterministic normalization for common OCR labels/synonyms."""
    low = (label or "").strip().lower()
    # Already canonical?
    if low in CANONICAL_KEYS:
        return low

    # Common synonyms
    if "cert" in low and ("naster" in low or "nașter" in low or "nastere" in low):
        return "cert_nastere"
    if low in {"ci", "carte identitate", "buletin", "buletin vechi", "ci veche", "ci_veche"}:
        return "ci_veche"
    if "adres" in low or "domicili" in low or "locuin" in low:
        return "dovada_adresa"
    if "politie" in low or "poli" in low or "furt" in low or "pierdere" in low:
        return "politie"

    if "cerere" in low and ("ajutor" in low or "social" in low):
        return "cerere_ajutor"
    if "carte" in low and "ident" in low:
        return "carte_identitate"
    if "venit" in low or "adever" in low or "cupon" in low:
        return "acte_venit"
    if "locuir" in low or "chiri" in low:
        return "acte_locuire"
    if "famil" in low or "certificat" in low and "casator" in low:
        return "acte_familie"
    if "iban" in low or "cont" in low or "extras" in low and "cont" in low:
        return "cont_bancar"

    return "unknown"

async def normalize_doc_name(text: str) -> str:
    if not USE_LLM_NORMALIZE:
        return _normalize_rule_based(text)

    resp = await client.chat.completions.create(
        model="gpt-5-mini",
        messages=[
            {"role": "system", "content": NORMALIZE_PROMPT},
            {"role": "user", "content": text},
        ],
        response_format={"type": "json_object"},
        temperature=0,
    )
    import json
    j = json.loads(resp.choices[0].message.content)
    return j.get("canonical", "unknown")


class DocIntakeAgent(Agent):
    name = "doc_intake"

    async def handle(self, state: AgentState) -> AgentState:
        sid = state.get("session_id", "chat-1")

        # Single fetch (no polling)
        recognized = []
        try:
            async with httpx.AsyncClient(timeout=5.0) as http:
                r = await http.get(
                    f"{LOCAL_URL}/uploads",
                    params={"session_id": sid},
                    headers={"X-Caller": "DocIntakeAgent"},
                )
                j = r.json()
                recognized = j.get("recognized", []) or []
        except Exception:
            recognized = []

        # Normalize recognized kinds (rule-based by default; optional LLM)
        docs = []
        for k in recognized:
            try:
                canonical = await normalize_doc_name(k)
            except Exception:
                canonical = _normalize_rule_based(k)
            if canonical == "unknown":
                continue
            docs.append({"kind": canonical, "status": "ok"})

        app = state.get("app") or {}
        # OCR is truth: overwrite docs with OCR-recognized docs (or set if empty)
        app["docs"] = docs
        state["app"] = app

        state.setdefault("steps", []).append({"ocr_docs": docs})

        # Return control to the caller agent
        return_to = state.pop("return_to", None)
        state["next_agent"] = return_to  # may be "social" or "ci", or any other use case
        # If return_to is None, graph will stop (safe)
        return state
