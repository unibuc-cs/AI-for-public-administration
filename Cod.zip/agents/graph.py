# A2A architecture
# This is the part that actually chains agents together. It’s simple: start at entry, then follow next_agent until there is none.
# This is a classic A2A pattern: each agent knows the next agent; the coordinator just loops.

# agents/graph.py
from __future__ import annotations

from typing import Dict

from .base import AgentState
from .entry_agent import EntryAgent
from .ci_agent import CIAgent
from .social_agent import SocialAgent
from .doc_intake_agent import DocIntakeAgent
from .scheduling_agent import SchedulingAgent
from .case_agent import CaseAgent
from .operator_agent import OperatorAgent

AGENTS: Dict[str, object] = {
    "entry": EntryAgent(),
    "ci": CIAgent(),
    "social": SocialAgent(),
    "doc_intake": DocIntakeAgent(),
    "scheduling": SchedulingAgent(),
    "case": CaseAgent(),
    "operator": OperatorAgent(),
}


async def run_agent_graph(state: AgentState, max_steps: int = 12) -> AgentState:
    current = state.get("next_agent") or "entry"
    steps = 0

    while current:
        steps += 1
        if steps > max_steps:
            state.setdefault("steps", []).append(
                {"error": f"Agent graph exceeded max_steps={max_steps}. Stopping to prevent infinite loop."}
            )
            state["next_agent"] = None
            if not state.get("reply"):
                state["reply"] = "Internal safety stop (too many steps). Please try again."
            return state

        agent = AGENTS.get(current)
        if agent is None:
            state.setdefault("steps", []).append({"error": f"Unknown agent: {current}"})
            state["next_agent"] = None
            state["reply"] = f"Internal error: unknown agent '{current}'."
            return state

        # prevent stale next_agent loops
        state.pop("next_agent", None)

        state = await agent.handle(state)
        current = state.get("next_agent")

    return state
