# agents/social_agent.py
from __future__ import annotations
import json
from pathlib import Path
from .base import Agent, AgentState

SOCIAL_CFG = json.loads((Path(__file__).parent / "checklists" / "social.json").read_text(encoding="utf-8"))
REQUIRED_DOCS = set(SOCIAL_CFG.get("required_docs", []))


class SocialAgent(Agent):
    name = "social"

    async def handle(self, state: AgentState) -> AgentState:
        app = state.get("app") or {}
        app["program"] = "AS"
        state["app"] = app

        state.setdefault("steps", [])

        if not app.get("docs"):
            if not state.get("_doc_intake_ran", False):
                state["_doc_intake_ran"] = True
                state["return_to"] = "social"
                state["next_agent"] = "doc_intake"
                state["reply"] = "Checking your uploaded documents (OCR)…"
                state["steps"].append({"handoff": "doc_intake"})
                return state

            state["reply"] = "I still don’t see recognized documents. Please upload files, then say “gata”."
            state["next_agent"] = None
            return state

        present = {d.get("kind") for d in app["docs"] if d.get("kind")}
        missing = sorted(list(REQUIRED_DOCS - present))

        if missing:
            state["steps"].append({"missing": missing})
            state["reply"] = (
                "Missing documents for Ajutor social:\n"
                + "\n".join([f"- {k}" for k in missing])
                + "\n\nPlease upload the missing documents, then say “gata”."
            )
            state["next_agent"] = None
            return state

        state["reply"] = "Documents complete for Ajutor social. Creating the case…"
        state["next_agent"] = "case"
        return state
