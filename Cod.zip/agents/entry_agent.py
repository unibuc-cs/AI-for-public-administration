# agents/entry_agent.py
from __future__ import annotations

import os
import re
from typing import Any, Dict, Optional

from .base import Agent, AgentState
from .llm_utils import classify_intent_with_llm

from .settings import LLM_USE


def _is_operator_session(state: AgentState) -> bool:
    sid = (state.get("session_id") or "").lower()
    return sid.startswith("op-") or state.get("role") == "operator"


def _has_min_profile(state: AgentState) -> bool:
    """
    Used to decide whether the user must be navigated to a form first.
    """
    person = state.get("person") or {}
    return bool(person.get("cnp") and person.get("nume") and person.get("prenume") and person.get("email"))


def _keyword_intent(text: str) -> str:
    t = text.lower().strip()

    # operator commands
    if re.search(r"\b(task|tasks|dosar|cases|claim|preia|done|complete|operator)\b", t):
        return "operator"

    # scheduling
    if re.search(r"\b(slot|programare|programeaz|reprogrameaz|anuleaz|appointment)\b", t):
        return "scheduling"

    # social
    if re.search(r"\b(ajutor social|venit minim|venit de incluziune|vmi)\b", t):
        return "social"

    # CI (use word boundaries so "ci" doesn't match random substrings)
    if re.search(r"\b(carte de identitate|buletin|act de identitate|ci)\b", t):
        return "ci"

    return "help"


class EntryAgent(Agent):
    """
    Thin intent router:
      - classify intent (LLM optional)
      - decide next_agent OR emit steps.navigate
      - domain logic stays in CI/Social/Operator agents
    """
    name = "entry"

    async def handle(self, state: AgentState) -> AgentState:
        text = state.get("message", "") or ""
        sid = state.get("session_id", "chat-1")

        state.setdefault("steps", [])

        # 1) classify
        intent = "help"
        entities: Dict[str, Any] = {}

        if LLM_USE:
            try:
                res = await classify_intent_with_llm(text)
                intent = (res.get("intent") or "help").strip().lower()
                entities = res.get("entities") or {}
            except Exception:
                intent = _keyword_intent(text)
        else:
            intent = _keyword_intent(text)

        state["intent"] = intent
        state["entities"] = entities

        # Track use-case for later scheduling routing
        if intent in ("ci", "social"):
            state["use_case"] = intent

        # 2) operator routing
        if intent == "operator":
            if _is_operator_session(state):
                state["next_agent"] = "operator"
            else:
                state["reply"] = "Operator actions require the operator dashboard."
                state["steps"].append({"navigate": "/operator"})
                state["next_agent"] = None
            return state

        # 3) scheduling routing (contextual)
        if intent == "scheduling":
            uc = state.get("use_case")
            if uc == "ci":
                state["reply"] = "Please pick a CI appointment slot in the CI form."
                state["steps"].append({"navigate": f"/user-ci?sid={sid}"})
                state["next_agent"] = None
                return state
            if uc == "social":
                state["reply"] = "Please pick a Social Aid slot in the Social Aid form."
                state["steps"].append({"navigate": f"/user-social?sid={sid}"})
                state["next_agent"] = None
                return state

            state["reply"] = "Do you mean ID card (carte de identitate) or Social Aid (ajutor social)?"
            state["next_agent"] = None
            return state

        # 4) CI routing
        if intent == "ci":
            if not _has_min_profile(state):
                state["reply"] = "Sure — let’s start the ID card flow. Please fill the CI form first."
                state["steps"].append({"navigate": f"/user-ci?sid={sid}"})
                state["next_agent"] = None
            else:
                state["next_agent"] = "ci"
            return state

        # 5) Social routing
        if intent == "social":
            if not _has_min_profile(state):
                state["reply"] = "Sure — let’s start Social Aid. Please fill the Social Aid form first."
                state["steps"].append({"navigate": f"/user-social?sid={sid}"})
                state["next_agent"] = None
            else:
                state["next_agent"] = "social"
            return state

        # 6) help/default
        state["reply"] = (
            "I can help with:\n"
            "• ID card (carte de identitate / CI)\n"
            "• Social Aid (ajutor social / venit minim de incluziune)\n"
            "• Scheduling (programare)\n\n"
            "Try:\n"
            "• “Vreau carte de identitate nouă”\n"
            "• “Vreau ajutor social”\n"
            "• “Vreau programare”"
        )
        state["next_agent"] = None
        return state
